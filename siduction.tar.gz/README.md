# Contained herein is my personal Solus Linux Scripts

You can get Solus from here    https://getsol.us/

I use KDE Plasma for my DE, but Budgie, GNOME and XFCE are also avaialble for download.

Some of the inclusions are:

~ flatpak {stable & beta}
~ nix-pkgs  
~ small tweaks to speed up networks, samba, etc

Solus is an independent distro that tweaked my interest.  Sometimes it can be a little finicky, but it is probably the most stable rolling release I've played with.  I still return to Solus from time to time to see what changes/improvement have been made.
