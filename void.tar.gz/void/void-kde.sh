#!/bin/bash
#!/usr/bin/env bash
# ==============================================================================
#   Author      : Tolga Erok
#   Version     : 1.0
#   Date        : 06-03-2026
#   Description : Install KDE goodies, PIM suite, Akonadi & friends on Void Linux
# ==============================================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

info()  { echo -e "${CYAN}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[  OK]${NC}  $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
err()   { echo -e "${RED}[ ERR]${NC}  $*"; exit 1; }

[[ $EUID -ne 0 ]] && err "Run as root: sudo $0"

echo -e ""
echo -e "${BOLD}${CYAN}╔══════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}${CYAN}║     KDE Goodies + PIM Suite - Void Linux     ║${NC}"
echo -e "${BOLD}${CYAN}╚══════════════════════════════════════════════╝${NC}"
echo -e ""

# ── sync ──────────────────────────────────────────────────────────────────────
info "Syncing repos..."
xbps-install -S || err "Repo sync failed"

# ── screenshots & media ───────────────────────────────────────────────────────
info "Installing screenshot & media tools..."
xbps-install -y \
    spectacle \
    gwenview \
    okular \
    kolourpaint \
    kcolorchooser \
    || warn "Some screenshot/media packages may not be available"
ok "Screenshot & media tools done"

# ── akonadi & backend ─────────────────────────────────────────────────────────
info "Installing Akonadi & backend..."
xbps-install -y \
    akonadi \
    akonadi-server \
    akonadi-calendar \
    akonadi-contacts \
    akonadi-mime \
    akonadi-notes \
    akonadi-search \
    akonadiconsole \
    || warn "Some Akonadi packages may not be available"
ok "Akonadi done"

# ── kde pim suite ─────────────────────────────────────────────────────────────
info "Installing KDE PIM suite..."
xbps-install -y \
    korganizer \
    kaddressbook \
    kmail \
    kmail-account-wizard \
    knotes \
    kalarm \
    kontact \
    ktnef \
    mbox-importer \
    pim-data-exporter \
    pim-sieve-editor \
    || warn "Some KDE PIM packages may not be available"
ok "KDE PIM suite done"

# ── kde utilities ─────────────────────────────────────────────────────────────
info "Installing KDE utilities..."
xbps-install -y \
    kcalc \
    kate \
    ark \
    filelight \
    kfind \
    kdiff3 \
    kdeconnect \
    kcharselect \
    kgpg \
    ktimer \
    kwalletmanager \
    partitionmanager \
    || warn "Some KDE utility packages may not be available"
ok "KDE utilities done"

# ── kde system tools ──────────────────────────────────────────────────────────
info "Installing KDE system tools..."
xbps-install -y \
    ksystemlog \
    kinfocenter \
    plasma-systemmonitor \
    sweeper \
    || warn "Some KDE system tool packages may not be available"
ok "KDE system tools done"

# ── plasma5support (fixes kickoff qml errors) ─────────────────────────────────
info "Installing plasma5support..."
xbps-install -y plasma5support && ok "plasma5support installed" || warn "plasma5support not available"

# ── enable akonadi server ─────────────────────────────────────────────────────
info "Enabling Akonadi server for user session..."
sudo -u "${SUDO_USER:-$USER}" akonadictl start 2>/dev/null && ok "Akonadi started" || warn "Akonadi start failed — try manually: akonadictl start"

# ── done ──────────────────────────────────────────────────────────────────────
echo -e ""
echo -e "${GREEN}${BOLD}All done!${NC} KDE goodies installed."
echo -e ""
echo -e "  ${CYAN}Spectacle${NC}     → screenshots"
echo -e "  ${CYAN}KOrganizer${NC}    → calendar"
echo -e "  ${CYAN}KMail${NC}         → email"
echo -e "  ${CYAN}KAddressBook${NC}  → contacts"
echo -e "  ${CYAN}Kontact${NC}       → unified PIM hub"
echo -e "  ${CYAN}KNotes${NC}        → sticky notes"
echo -e "  ${CYAN}KAlarm${NC}        → alarms & reminders"
echo -e "  ${CYAN}KDE Connect${NC}   → phone integration"
echo -e ""
echo -e "  Log out and back in if apps don't appear in the menu brother"
echo -e ""
