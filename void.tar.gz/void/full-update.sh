#!/bin/bash
#!/usr/bin/env bash
# ==============================================================================
#   Author      : Tolga Erok
#   Version     : 1.2
#   Date        : 06-03-2026
#   Description : Full system update for Void Linux
# ==============================================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

info()  { echo -e "${CYAN}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[  OK]${NC}  $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
err()   { echo -e "${RED}[ ERR]${NC}  $*"; exit 1; }

[[ $EUID -ne 0 ]] && err "Run as root: sudo $0"

echo -e ""
echo -e "${BOLD}${CYAN}╔══════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}${CYAN}║        Void Linux Full System Update         ║${NC}"
echo -e "${BOLD}${CYAN}╚══════════════════════════════════════════════╝${NC}"
echo -e ""

# ── sync + full upgrade in one shot ───────────────────────────────────────────
info "Syncing repos and upgrading system..."
xbps-install -Syu || err "Upgrade failed"
ok "System upgraded"

# ── remove orphans (auto) ─────────────────────────────────────────────────────
info "Checking for orphaned packages..."
orphans=$(xbps-query -O 2>/dev/null)
if [[ -n "$orphans" ]]; then
    warn "Orphaned packages found — removing automatically..."
    echo "$orphans"
    xbps-remove -Ryo && ok "Orphans removed"
else
    ok "No orphans found"
fi

# ── clean pkg cache ───────────────────────────────────────────────────────────
info "Cleaning package cache..."
xbps-remove -Oy && ok "Cache cleaned"

# ── update flatpaks if installed ──────────────────────────────────────────────
#if command -v flatpak &>/dev/null; then
#    info "Updating Flatpaks..."
#    flatpak update --noninteractive -y 2>/dev/null && ok "Flatpaks updated"
#else
#    info "Flatpak not installed — skipping"
#fi

# ── done ──────────────────────────────────────────────────────────────────────
echo -e ""
echo -e "${GREEN}${BOLD}All done!${NC} System is fully up to date."
echo -e ""
