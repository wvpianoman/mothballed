#!/bin/bash
#!/usr/bin/env bash
# ==============================================================================
#   Author      : Tolga Erok
#   Version     : 1.0
#   Date        : 06-03-2026
#   Description : Network optimisation for Void Linux (wireless) in 5 steps
# ==============================================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

iface="wlp0s20u1"

info()  { echo -e "${CYAN}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[  OK]${NC}  $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
err()   { echo -e "${RED}[ ERR]${NC}  $*"; exit 1; }

[[ $EUID -ne 0 ]] && err "Run as root: sudo $0"

echo -e ""
echo -e "${BOLD}${CYAN}╔══════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}${CYAN}║        Void Linux Network Optimiser          ║${NC}"
echo -e "${BOLD}${CYAN}║        Interface: ${iface}              ║${NC}"
echo -e "${BOLD}${CYAN}╚══════════════════════════════════════════════╝${NC}"
echo -e ""

# ── step 1: load BBR ──────────────────────────────────────────────────────────
info "Loading tcp_bbr module..."
modprobe tcp_bbr 2>/dev/null && ok "tcp_bbr loaded" || warn "tcp_bbr not available (older kernel?)"

# ── step 2: sysctl tuning ─────────────────────────────────────────────────────
info "Applying sysctl network tweaks..."

sysctl_file="/etc/sysctl.d/99-network-tolga.conf"

mkdir -p /etc/sysctl.d
cat > "${sysctl_file}" <<EOF
# ==============================================================
#  Tolga Erok - Network optimisation - Void Linux
# ==============================================================

# BBR congestion control
net.core.default_qdisc            = cake
net.ipv4.tcp_congestion_control   = bbr

# TCP buffer sizes
net.core.rmem_max                  = 16777216
net.core.wmem_max                  = 16777216
net.core.rmem_default              = 262144
net.core.wmem_default              = 262144
net.ipv4.tcp_rmem                  = 4096 87380 16777216
net.ipv4.tcp_wmem                  = 4096 65536 16777216

# General TCP performance
net.ipv4.tcp_fastopen              = 3
net.ipv4.tcp_tw_reuse              = 1
net.ipv4.tcp_fin_timeout           = 15
net.ipv4.tcp_keepalive_time        = 300
net.ipv4.tcp_keepalive_intvl       = 30
net.ipv4.tcp_keepalive_probes      = 5
net.ipv4.tcp_mtu_probing           = 1
net.ipv4.tcp_slow_start_after_idle = 0

# Increase connection backlog
net.core.netdev_max_backlog        = 16384
net.core.somaxconn                 = 8192

# IPv4 hardening / misc
net.ipv4.conf.all.rp_filter        = 1
net.ipv4.tcp_syncookies            = 1
EOF

sysctl --system &>/dev/null && ok "sysctl settings applied" || warn "sysctl apply had warnings"

# ── step 3: CAKE qdisc on wireless interface ──────────────────────────────────
info "Applying CAKE qdisc to ${iface}..."

if tc qdisc replace dev "${iface}" root cake bandwidth 100mbit 2>/dev/null; then
    ok "CAKE applied to ${iface}"
else
    warn "CAKE failed — falling back to fq_codel"
    tc qdisc replace dev "${iface}" root fq_codel && ok "fq_codel applied" || warn "qdisc fallback also failed"
fi

# ── step 4: verify BBR is active ──────────────────────────────────────────────
info "Verifying congestion control..."
cc=$(sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null)
qd=$(sysctl -n net.core.default_qdisc 2>/dev/null)
echo -e "  Congestion control : ${GREEN}${cc}${NC}"
echo -e "  Default qdisc      : ${GREEN}${qd}${NC}"

# ── step 5: persist CAKE via runit (survive reboot) ───────────────────────────
info "Persisting CAKE qdisc across reboots..."

persist_script="/etc/rc.local"

# Void doesn't always have rc.local — create it if missing
if [[ ! -f "${persist_script}" ]]; then
    cat > "${persist_script}" <<RCEOF
#!/bin/sh
# rc.local — runs at boot
RCEOF
    chmod +x "${persist_script}"
    info "Created ${persist_script}"
fi

cake_line="tc qdisc replace dev ${iface} root cake bandwidth 100mbit"

if ! grep -qF "${cake_line}" "${persist_script}"; then
    echo "${cake_line}" >> "${persist_script}"
    ok "CAKE qdisc boot persistence added to ${persist_script}"
else
    warn "CAKE boot entry already in ${persist_script} — skipping"
fi

# ── done ──────────────────────────────────────────────────────────────────────
echo -e ""
echo -e "${GREEN}${BOLD}All done!${NC}"
echo -e "  BBR + CAKE active now and on every reboot."
echo -e "Brother.....  If browsing still feels slow, consider switching DNS to ${CYAN}1.1.1.1${NC} / ${CYAN}9.9.9.9${NC}."
echo -e ""
